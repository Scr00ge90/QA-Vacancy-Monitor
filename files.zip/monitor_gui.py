import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import sys
import os
import threading
from datetime import date

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPT_PATH = os.path.join(BASE_DIR, "monitor.py")
LOG_DIR = os.path.join(BASE_DIR, "logs")
PID_FILE = os.path.join(BASE_DIR, "monitor_pid.txt")
PYTHON = sys.executable  # Берём тот же Python которым запущен GUI

# --- Цвета ---
CLR_BG = "#1e1e2e"
CLR_PANEL = "#2a2a3e"
CLR_BTN = "#3a3a5c"
CLR_BTN_START = "#2d6a4f"
CLR_BTN_STOP = "#7d2d2d"
CLR_BTN_ACTIVE = "#52b788"
CLR_TEXT = "#cdd6f4"
CLR_MUTED = "#6c7086"
CLR_GREEN = "#a6e3a1"
CLR_RED = "#f38ba8"
CLR_YELLOW = "#f9e2af"
CLR_BLUE = "#89b4fa"

class MonitorGUI:
    def __init__(self, root):
        self.root = root
        root.title("QA Telegram Monitor")
        root.geometry("800x580")
        root.configure(bg=CLR_BG)
        root.resizable(True, True)

        self.process = None
        self.safe_mode = tk.BooleanVar(value=True)   # по умолчанию Safe Mode включён
        self.parse_history = tk.BooleanVar(value=False)
        self._log_lines_count = 0  # отслеживаем сколько строк уже в логе

        self._build_header()
        self._build_controls()
        self._build_indicators()
        self._build_log()
        self._build_statusbar()

        self.update_status()

    # ── UI ──────────────────────────────────────────────────────────────

    def _build_header(self):
        hdr = tk.Frame(self.root, bg=CLR_PANEL, pady=10)
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="QA Telegram Monitor", font=("Consolas", 16, "bold"),
                 bg=CLR_PANEL, fg=CLR_TEXT).pack(side=tk.LEFT, padx=16)
        self.status_dot = tk.Label(hdr, text="●", font=("Arial", 18),
                                   bg=CLR_PANEL, fg=CLR_RED)
        self.status_dot.pack(side=tk.RIGHT, padx=6)
        self.status_label = tk.Label(hdr, text="STOPPED", font=("Consolas", 12),
                                     bg=CLR_PANEL, fg=CLR_RED)
        self.status_label.pack(side=tk.RIGHT, padx=4)

    def _build_controls(self):
        ctrl = tk.Frame(self.root, bg=CLR_BG, pady=8)
        ctrl.pack(fill=tk.X, padx=12)

        self.btn_start = self._btn(ctrl, "▶  Start", CLR_BTN_START, self.start_monitor)
        self.btn_start.pack(side=tk.LEFT, padx=4)

        self.btn_stop = self._btn(ctrl, "■  Stop", CLR_BTN_STOP, self.stop_monitor)
        self.btn_stop.pack(side=tk.LEFT, padx=4)

        self._btn(ctrl, "📂  Open Logs", CLR_BTN, self.open_logs).pack(side=tk.LEFT, padx=4)

        self._btn(ctrl, "🗑  Clear Log", CLR_BTN, self.clear_log).pack(side=tk.LEFT, padx=4)

    def _build_indicators(self):
        ind = tk.Frame(self.root, bg=CLR_BG, pady=4)
        ind.pack(fill=tk.X, padx=12)

        # Safe Mode
        safe_frame = tk.Frame(ind, bg=CLR_PANEL, padx=10, pady=6)
        safe_frame.pack(side=tk.LEFT, padx=4)
        tk.Label(safe_frame, text="Safe Mode", font=("Consolas", 10),
                 bg=CLR_PANEL, fg=CLR_MUTED).pack(side=tk.LEFT, padx=(0, 6))
        self.safe_cb = tk.Checkbutton(safe_frame, variable=self.safe_mode,
                                       bg=CLR_PANEL, fg=CLR_YELLOW,
                                       selectcolor=CLR_BTN, activebackground=CLR_PANEL,
                                       command=self._on_toggle)
        self.safe_cb.pack(side=tk.LEFT)
        self.safe_lbl = tk.Label(safe_frame, text="ON", font=("Consolas", 10, "bold"),
                                  bg=CLR_PANEL, fg=CLR_YELLOW)
        self.safe_lbl.pack(side=tk.LEFT)

        # Parse History
        hist_frame = tk.Frame(ind, bg=CLR_PANEL, padx=10, pady=6)
        hist_frame.pack(side=tk.LEFT, padx=4)
        tk.Label(hist_frame, text="Parse History", font=("Consolas", 10),
                 bg=CLR_PANEL, fg=CLR_MUTED).pack(side=tk.LEFT, padx=(0, 6))
        self.hist_cb = tk.Checkbutton(hist_frame, variable=self.parse_history,
                                       bg=CLR_PANEL, fg=CLR_BLUE,
                                       selectcolor=CLR_BTN, activebackground=CLR_PANEL,
                                       command=self._on_toggle)
        self.hist_cb.pack(side=tk.LEFT)
        self.hist_lbl = tk.Label(hist_frame, text="OFF", font=("Consolas", 10, "bold"),
                                  bg=CLR_PANEL, fg=CLR_MUTED)
        self.hist_lbl.pack(side=tk.LEFT)

        # Sent today counter
        cnt_frame = tk.Frame(ind, bg=CLR_PANEL, padx=10, pady=6)
        cnt_frame.pack(side=tk.RIGHT, padx=4)
        tk.Label(cnt_frame, text="Откликов сегодня:", font=("Consolas", 10),
                 bg=CLR_PANEL, fg=CLR_MUTED).pack(side=tk.LEFT, padx=(0, 6))
        self.sent_lbl = tk.Label(cnt_frame, text="0", font=("Consolas", 10, "bold"),
                                  bg=CLR_PANEL, fg=CLR_GREEN)
        self.sent_lbl.pack(side=tk.LEFT)

    def _build_log(self):
        log_frame = tk.Frame(self.root, bg=CLR_BG)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=(4, 0))

        tk.Label(log_frame, text="LOG", font=("Consolas", 9),
                 bg=CLR_BG, fg=CLR_MUTED).pack(anchor=tk.W)

        self.log_area = scrolledtext.ScrolledText(
            log_frame,
            font=("Consolas", 10),
            bg="#13131f", fg=CLR_TEXT,
            insertbackground=CLR_TEXT,
            relief=tk.FLAT, bd=0,
            height=20
        )
        self.log_area.pack(fill=tk.BOTH, expand=True)
        self.log_area.config(state=tk.DISABLED)

        # Цветовые теги
        self.log_area.tag_config("ok",      foreground=CLR_GREEN)
        self.log_area.tag_config("error",   foreground=CLR_RED)
        self.log_area.tag_config("warn",    foreground=CLR_YELLOW)
        self.log_area.tag_config("info",    foreground=CLR_BLUE)
        self.log_area.tag_config("history", foreground="#cba6f7")
        self.log_area.tag_config("default", foreground=CLR_TEXT)

    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg=CLR_PANEL, pady=3)
        bar.pack(fill=tk.X, side=tk.BOTTOM)
        self.statusbar = tk.Label(bar, text="Готов к запуску", font=("Consolas", 9),
                                   bg=CLR_PANEL, fg=CLR_MUTED)
        self.statusbar.pack(side=tk.LEFT, padx=10)

    def _btn(self, parent, text, color, command):
        return tk.Button(parent, text=text, command=command,
                         bg=color, fg=CLR_TEXT,
                         font=("Consolas", 10), relief=tk.FLAT,
                         padx=12, pady=6, cursor="hand2",
                         activebackground=CLR_BTN_ACTIVE, activeforeground="#000")

    # ── Логика ──────────────────────────────────────────────────────────

    def _on_toggle(self):
        """Обновляем лейблы при смене чекбоксов"""
        if self.safe_mode.get():
            self.safe_lbl.config(text="ON", fg=CLR_YELLOW)
        else:
            self.safe_lbl.config(text="OFF", fg=CLR_MUTED)

        if self.parse_history.get():
            self.hist_lbl.config(text="ON", fg=CLR_BLUE)
        else:
            self.hist_lbl.config(text="OFF", fg=CLR_MUTED)

        if self.is_running():
            self.set_status("Изменения применятся после перезапуска")

    def is_running(self):
        return self.process is not None and self.process.poll() is None

    def start_monitor(self):
        if self.is_running():
            messagebox.showinfo("Info", "Скрипт уже запущен")
            return

        env = os.environ.copy()
        env["SAFE_MODE"] = "true" if self.safe_mode.get() else "false"
        env["PARSE_HISTORY"] = "true" if self.parse_history.get() else "false"

        def target():
            self.process = subprocess.Popen(
                [PYTHON, SCRIPT_PATH],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace"
            )
            for line in self.process.stdout:
                self.append_log(line.rstrip())
            self.append_log("── процесс завершён ──", tag="warn")

        threading.Thread(target=target, daemon=True).start()
        self.set_status("Скрипт запущен")

    def stop_monitor(self):
        if not self.is_running():
            messagebox.showinfo("Info", "Скрипт не запущен")
            return
        try:
            self.process.terminate()
            self.process.wait(timeout=5)
        except Exception:
            try:
                self.process.kill()
            except Exception:
                pass
        self.process = None
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
        self.append_log("── скрипт остановлен ──", tag="warn")
        self.set_status("Остановлен")

    def open_logs(self):
        if os.path.exists(LOG_DIR):
            os.startfile(LOG_DIR)
        else:
            messagebox.showwarning("Warning", "Папка логов не найдена")

    def clear_log(self):
        self.log_area.config(state=tk.NORMAL)
        self.log_area.delete(1.0, tk.END)
        self.log_area.config(state=tk.DISABLED)
        self._log_lines_count = 0

    def append_log(self, text, tag=None):
        if not text:
            return
        if tag is None:
            if "[OK]" in text or "Отправлено" in text:
                tag = "ok"
            elif "[ERROR]" in text:
                tag = "error"
            elif "[CONFIG]" in text or "[START]" in text:
                tag = "info"
            elif "[HISTORY]" in text:
                tag = "history"
            elif "[SAFE MODE]" in text or "──" in text:
                tag = "warn"
            else:
                tag = "default"

        def _insert():
            self.log_area.config(state=tk.NORMAL)
            self.log_area.insert(tk.END, text + "\n", tag)
            self.log_area.yview(tk.END)
            self.log_area.config(state=tk.DISABLED)

        self.root.after(0, _insert)

    def set_status(self, text):
        self.root.after(0, lambda: self.statusbar.config(text=text))

    def update_sent_count(self):
        """Считаем строки в лог-файле как число откликов"""
        log_file = os.path.join(LOG_DIR, f"sent_log_{date.today()}.txt")
        count = 0
        if os.path.exists(log_file):
            try:
                with open(log_file, "r", encoding="utf-8") as f:
                    count = sum(1 for line in f if line.strip())
            except Exception:
                pass
        self.sent_lbl.config(text=str(count))

    def update_status(self):
        if self.is_running():
            self.status_label.config(text="RUNNING", fg=CLR_GREEN)
            self.status_dot.config(fg=CLR_GREEN)
            self.btn_start.config(state=tk.DISABLED)
            self.btn_stop.config(state=tk.NORMAL)
        else:
            self.status_label.config(text="STOPPED", fg=CLR_RED)
            self.status_dot.config(fg=CLR_RED)
            self.btn_start.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.DISABLED)

        self.update_sent_count()
        self.root.after(1000, self.update_status)


if __name__ == "__main__":
    root = tk.Tk()
    gui = MonitorGUI(root)
    root.mainloop()
