@echo off
chcp 65001 > nul
title QA Telegram Monitor

set "BASE_DIR=%~dp0"
set "PYTHON=C:\Users\vpak9\AppData\Local\Python\bin\python.exe"
set "SCRIPT=%BASE_DIR%monitor.py"
set "PID_FILE=%BASE_DIR%monitor_pid.txt"
set "LOG_DIR=%BASE_DIR%logs"
set "ENV_FILE=%BASE_DIR%.env"

:MENU
cls

:: --- Читаем текущие значения из .env ---
set "SAFE_VAL=unknown"
set "HISTORY_VAL=unknown"
for /f "tokens=1,2 delims==" %%a in ('type "%ENV_FILE%" ^| findstr /i "SAFE_MODE PARSE_HISTORY"') do (
    if /i "%%a"=="SAFE_MODE" set "SAFE_VAL=%%b"
    if /i "%%a"=="PARSE_HISTORY" set "HISTORY_VAL=%%b"
)

echo ==============================
echo       QA Telegram Monitor
echo ==============================
if exist "%PID_FILE%" (
    echo   Status: RUNNING [OK]
) else (
    echo   Status: STOPPED [X]
)
echo   Safe mode:     %SAFE_VAL%
echo   Parse history: %HISTORY_VAL%
echo ==============================
echo 1. Start script
echo 2. Stop script
echo 3. Toggle Safe mode
echo 4. Toggle Parse history
echo 5. Log today
echo 6. Status
echo 7. Open logs folder
echo 8. Exit
echo ==============================
set /p choice=Choice: 

if "%choice%"=="1" goto START
if "%choice%"=="2" goto STOP
if "%choice%"=="3" goto TOGGLE_SAFE
if "%choice%"=="4" goto TOGGLE_HISTORY
if "%choice%"=="5" goto LOG_TODAY
if "%choice%"=="6" goto STATUS
if "%choice%"=="7" goto OPEN_LOGS
if "%choice%"=="8" exit
goto MENU

:START
if exist "%PID_FILE%" (
    echo Skript uzhe zapushchen.
    pause
    goto MENU
)
echo Starting...
start "QA Monitor" "%PYTHON%" "%SCRIPT%"
echo Done.
pause
goto MENU

:STOP
if not exist "%PID_FILE%" (
    echo Skript ne zapushchen.
    pause
    goto MENU
)
set /p PID=<"%PID_FILE%"
echo Stopping PID %PID%...
taskkill /PID %PID% /F /T > nul 2>&1
if exist "%PID_FILE%" del "%PID_FILE%"
echo Stopped.
pause
goto MENU

:TOGGLE_SAFE
set "SAFE_VAL=unknown"
for /f "tokens=1,2 delims==" %%a in ('type "%ENV_FILE%" ^| findstr /i "SAFE_MODE"') do (
    if /i "%%a"=="SAFE_MODE" set "SAFE_VAL=%%b"
)
if /i "%SAFE_VAL%"=="true" (
    powershell -Command "(Get-Content '%ENV_FILE%') -replace 'SAFE_MODE=true','SAFE_MODE=false' | Set-Content '%ENV_FILE%'"
    echo Safe mode: OFF -- WARNING: real messages will be sent!
) else (
    powershell -Command "(Get-Content '%ENV_FILE%') -replace 'SAFE_MODE=false','SAFE_MODE=true' | Set-Content '%ENV_FILE%'"
    echo Safe mode: ON -- test mode, no messages sent.
)
pause
goto MENU

:TOGGLE_HISTORY
set "HISTORY_VAL=unknown"
for /f "tokens=1,2 delims==" %%a in ('type "%ENV_FILE%" ^| findstr /i "PARSE_HISTORY"') do (
    if /i "%%a"=="PARSE_HISTORY" set "HISTORY_VAL=%%b"
)
if /i "%HISTORY_VAL%"=="false" (
    powershell -Command "(Get-Content '%ENV_FILE%') -replace 'PARSE_HISTORY=false','PARSE_HISTORY=true' | Set-Content '%ENV_FILE%'"
    echo Parse history: ON -- will scan old messages on next start.
) else (
    powershell -Command "(Get-Content '%ENV_FILE%') -replace 'PARSE_HISTORY=true','PARSE_HISTORY=false' | Set-Content '%ENV_FILE%'"
    echo Parse history: OFF.
)
pause
goto MENU

:LOG_TODAY
set "TODAY=%date:~0,4%-%date:~5,2%-%date:~8,2%"
set "LOG_FILE=%LOG_DIR%\sent_log_%TODAY%.txt"
if exist "%LOG_FILE%" (
    type "%LOG_FILE%"
) else (
    echo No log for today.
)
pause
goto MENU

:STATUS
if exist "%PID_FILE%" (
    set /p PID=<"%PID_FILE%"
    echo [STATUS] Running - PID: %PID%
) else (
    echo [STATUS] Not running
)
set "TODAY=%date:~0,4%-%date:~5,2%-%date:~8,2%"
set "LOG_FILE=%LOG_DIR%\sent_log_%TODAY%.txt"
if exist "%LOG_FILE%" (
    for /f %%a in ('type "%LOG_FILE%" ^| find /c /v ""') do echo [LOG] Sent today: %%a
) else (
    echo [LOG] No activity today
)
echo   Safe mode:     %SAFE_VAL%
echo   Parse history: %HISTORY_VAL%
pause
goto MENU

:OPEN_LOGS
if exist "%LOG_DIR%" (
    explorer "%LOG_DIR%"
) else (
    echo Logs folder not found.
)
pause
goto MENU
